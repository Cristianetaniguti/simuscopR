# simuscopR
Wrap-up R package for SimusCop simulations.
